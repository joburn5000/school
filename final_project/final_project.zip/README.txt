README

To run this code, all you need to do is compile all the code and the HDL file,
and then run the C code which handles the USB connection to the keyboard. Then, press
space to start the game, and then you can move left and right with a and d, and can
fire with the space button. The game ends once either you get hit by an alien, or
you clear all of the aliens.